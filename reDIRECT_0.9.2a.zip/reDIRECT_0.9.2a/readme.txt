reDIRECT v0.9.2a. 
PHASE TWO

KSP version: 1.4.1. 

Release Date: 07-04-2018.

Created by BENJEE10. 

Thank you for downloading reDIRECT, a revamp of the DIRECT mod which introduces shuttle-derived parts for Kerbal Space Program. 

This BETA release includes parts required for a Shuttle stack and the Jupiter family of rockets.  

INSTALLATION:

Simply drag and drop the "reDIRECT" folder into your KSP gameData directory. 

CHANGELOG:

0.9.2a. ALPHA TEST RELEASE OF PHASE II. 
	- Testing three-part Orion capsule analogue. All values/configs are placeholder. 

0.9.1. BETA RELEASE.
	- Added KD75k "Monsoon" five-segment Solid Rocket Booster. 
	- Added KD25K "Thunderstorm" two-segment Solid Rocket Booster. 
	- Minor SRB texture improvements. 
	- Minor Tank Endcap texture improvements.
	- Added Jupiter Upper Stage parts (fuel tank and engine mount). 
	- Added new upper stage engine, KL10-B.
	- Rebalanced to be closer to stock values. 
	- Added placeholder KS-25B "Rainstorm" engine (uses Stock SSME model) to account for increased mass of fuel tanks. 

0.9.0. BETA RELEASE. 
	- Initial release of Phase I. 

Artwork created by & copyright Benedict Jewer 2018. 
This mod was made possible by donations by forum user HOOHUNGLOW. 
All rights reserved. 