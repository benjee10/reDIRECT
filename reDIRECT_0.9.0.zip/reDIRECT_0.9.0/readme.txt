reDIRECT v0.9.0. 
PHASE ONE

KSP version: 1.4.1. 

Release Date: 13-03-2018.

Created by BENJEE10. 

Thank you for downloading reDIRECT, a revamp of the DIRECT mod which introduces shuttle-derived parts for Kerbal Space Program. 

This BETA release includes parts required for a Shuttle stack and the basic Jupiter launcher configuration, Jupiter-130. 

INSTALLATION:

Simply drag and drop the "reDIRECT" folder into your KSP gameData directory. 

CHANGELOG:

0.9.0. BETA RELEASE. 

	- Initial release of Phase I. 

Artwork created by & copyright Benedict Jewer 2018. 
All rights reserved. 